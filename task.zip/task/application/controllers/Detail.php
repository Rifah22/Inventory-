<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Detail_model');
    }

public function view($id) {
        $data['product'] = $this->Detail_model->get_product_detail($id);

        if (!$data['product']) {
            show_404(); 
        }

        $this->load->view('products/detail_view', $data);
    }
}
