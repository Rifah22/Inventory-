<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brands extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Brand_model');
        $this->load->library('pagination');
    }

    public function index() {
        
        $name = $this->input->get('name');
        $code = $this->input->get('code');
        $status = $this->input->get('status');

        
        $config = [];
        $config['base_url'] = site_url('brands/index');
        $config['total_rows'] = $this->Brand_model->count_filtered_brands($name, $code, $status);
        $config['per_page'] = 5;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';

       
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close'] = '</span></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';

        $this->pagination->initialize($config);

        
        $page = ($this->input->get('page')) ? $this->input->get('page') : 0;

        $data['brands'] = $this->Brand_model->get_filtered_brands($config['per_page'], $page, $name, $code, $status);

        $data['pagination'] = $this->pagination->create_links();

        $data['name'] = $name;
        $data['code'] = $code;
        $data['status'] = $status;

        $this->layout('brands/index', $data);
    }

    public function add() {
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required|is_unique[brands.code]');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            $this->layout('brands/add');
        } else {
            $data = [
                'name' => $this->input->post('name'),
                'code' => $this->input->post('code'),
                'status' => $this->input->post('status')
            ];
            $this->Brand_model->insert($data);
            $this->session->set_flashdata('success','Brand added successfully!');
            redirect('brands');
        }
    }

    public function edit($id) {
        $brand = $this->Brand_model->get($id);
        if(!$brand){ show_404(); }

        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            $data['brand'] = $brand;
            $this->layout('brands/edit',$data);
        } else {
            $code = $this->input->post('code');
            if($this->Brand_model->code_exists_other($code,$id)){
                $this->session->set_flashdata('error','Code already exists!');
                redirect('brands/edit/'.$id);
            }
            $data = [
                'name' => $this->input->post('name'),
                'code' => $code,
                'status' => $this->input->post('status')
            ];
            $this->Brand_model->update($id,$data);
            $this->session->set_flashdata('success','Brand updated successfully!');
            redirect('brands');
        }
    }

    public function delete($id) {
        $this->Brand_model->delete($id);
        $this->session->set_flashdata('successs','Brand deleted successfully!');
        redirect('brands');
    }

    public function view($id){
        $data['brand'] = $this->Brand_model->get($id);
        if(!$data['brand']) show_404();
        $this->layout('brands/view',$data);
    }
}
/*

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brands extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Brand_model');
    }

    public function index() {

        $name = $this->input->get('name');
        $code = $this->input->get('code');
        $status = $this->input->get('status');

        $this->db->select('*');
        $this->db->from('brands');

        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);

        $data['brands'] = $this->db->get()->result();

 
        $this->layout('brands/index', $data);
    }
      
    public function add() {
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required|is_unique[brands.code]');
        $this->form_validation->set_rules('status','Status','required');
        if($this->form_validation->run()===FALSE){
            
            $data['brands'] = $this->db->get('brands')->result();
            $this->layout('brands/add',$data);
        } else {
            $data = [
                'name' => $this->input->post('name'),
                'code' => $this->input->post('code'),
                'status' => $this->input->post('status')
            ];
            $this->Brand_model->insert($data);
            $this->session->set_flashdata('success','Brand added successfully!');
            redirect('brands');
        }
    }

    public function edit($id) {
        $brand = $this->Brand_model->get($id);
        if(!$brand){ show_404(); }
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            $data['brand'] = $brand;
            
            $this->layout('brands/edit',$data);
        } else {
            $code = $this->input->post('code');
            if($this->Brand_model->code_exists_other($code,$id)){
                $this->session->set_flashdata('error','Code already exists!');
                redirect('brands/edit/'.$id);
            }
            $data = [
                'name' => $this->input->post('name'),
                'code' => $code,
                'status' => $this->input->post('status')
            ];
            $this->Brand_model->update($id,$data);
            $this->session->set_flashdata('success','Brand updated successfully!');
            redirect('brands');
        }
    }

    public function delete($id) {
        $this->Brand_model->delete($id);
        $this->session->set_flashdata('successs','Brand deleted successfully!');
        redirect('brands');
    }

    public function view($id){
        $data['brand'] = $this->Brand_model->get($id);
        if(!$data['brand']) show_404();
        
        $this->layout('brands/view',$data);
    }
}
*/