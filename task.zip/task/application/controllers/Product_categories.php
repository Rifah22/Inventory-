<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_categories extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_category_model');
        $this->load->library('form_validation');
    }

    public function index() {

        // Get search filters
        $name = $this->input->get('name');
        $code = $this->input->get('code');
        $status = $this->input->get('status');

        // Pagination config
        $config = [];
        $config['base_url'] = site_url('product_categories/index');
        $config['total_rows'] = $this->Product_category_model->count_filtered_categories($name, $code, $status);
        $config['per_page'] = 2;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';

        // Bootstrap pagination styling
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close'] = '</span></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';

        $this->pagination->initialize($config);

        // Current page
        $page = ($this->input->get('page')) ? $this->input->get('page') : 0;

        // Fetch filtered brands with pagination
        $data['categories'] = $this->Product_category_model->get_filtered_categories($config['per_page'], $page, $name, $code, $status);

        // Pass pagination links
        $data['pagination'] = $this->pagination->create_links();

        // Keep filters in view
        $data['name'] = $name;
        $data['code'] = $code;
        $data['status'] = $status;
       

/*
        $this->db->select('*');
        $this->db->from('product_categories');

        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);

        $data['categories'] = $this->db->get()->result();*/

        
 

       /* $search = $this->input->get('search', true);
        $this->db->like('name', $search);
        $this->db->or_like('code', $search);
        $data['categories'] = $this->db->get('product_categories')->result();*/

        $this->layout('product_categories/index', $data);
    }

    public function add() {
        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required|is_unique[product_categories.code]');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){

            $data['categories'] = $this->db->get('product_categories')->result();
            $this->layout('product_categories/add', $data);
        } else {
            $data = [
                'name' => $this->input->post('name'),
                'code' => $this->input->post('code'),
                'status' => $this->input->post('status')
            ];
            $this->Product_category_model->insert($data);
            $this->session->set_flashdata('success','Category added successfully!');
            redirect('product_categories');
        }
    }

    public function edit($id) {
        $category = $this->Product_category_model->get($id);
        if(!$category) show_404();

        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            $data['category'] = $category;
            
            $this->layout('product_categories/edit', $data);
        } else {
            $code = $this->input->post('code');
            if($this->Product_category_model->code_exists_other($code,$id)){
                $this->session->set_flashdata('error','Code already exists!');
                redirect('product_categories/edit/'.$id);
            }
            $data = [
                'name' => $this->input->post('name'),
                'code' => $code,
                'status' => $this->input->post('status')
            ];
            $this->Product_category_model->update($id,$data);
            $this->session->set_flashdata('success','Category updated successfully!');
            redirect('product_categories');
        }
    }

    public function delete($id) {
        $this->Product_category_model->delete($id);
        $this->session->set_flashdata('successs','Category deleted successfully!');
        redirect('product_categories');
    }

    public function view($id) {
        $data['category'] = $this->Product_category_model->get($id);
        if(!$data['category']) show_404();
        
        $this->layout('product_categories/view', $data);
    }
}
