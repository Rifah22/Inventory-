<?php
class Logins extends MY_Controller {
    
     public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->database();
        $this->load->library('session');
         $this->load->model('User_model');
         $this->load->library('form_validation');
    }

     public function login()
   {
      $email    = $this->input->post('email');
      $password = $this->input->post('password');

       // Check in database
        $user = $this->db->get_where('users', ['email' => $email])->row();

         if ($user && password_verify($password, $user->password)) {
        

        
        redirect('Forms/information');
    } else {
        $this->session->set_flashdata('error', 'Email or password do not match!');
            redirect('Forms/general');

    }
}




}