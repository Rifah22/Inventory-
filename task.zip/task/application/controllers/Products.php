<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Brand_model');
        $this->load->model('Product_category_model');
        $this->load->library(['form_validation','pagination']);
    }

    public function index() {
        $name = $this->input->get('name', true);
        $code = $this->input->get('code', true);
        $brand_id = $this->input->get('brand_id', true);
        $category_id = $this->input->get('category_id', true);

        
        $config = [];
        $config['base_url'] = site_url('products/index');
        $config['total_rows'] = $this->Product_model->count_filtered_products($name, $code, $brand_id, $category_id);
        $config['per_page'] = 2;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';

        
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close'] = '</span></li>';
        $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close'] = '</span></li>';
        $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close'] = '</span></li>';
        $config['cur_tag_open'] = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close'] = '</span></li>';
        $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close'] = '</span></li>';

        $this->pagination->initialize($config);

        $page = ($this->input->get('page')) ? $this->input->get('page') : 0;

        $data['products'] = $this->Product_model->get_filtered_products(
            $config['per_page'], $page, $name, $code, $brand_id, $category_id
        );
        $data['pagination'] = $this->pagination->create_links();
        $data['brands'] = $this->Brand_model->get_all();
        $data['categories'] = $this->Product_category_model->get_all();
        $data['name'] = $name;
        $data['code'] = $code;
        $data['brand_id'] = $brand_id;
        $data['category_id'] = $category_id;

        $this->layout('products/index', $data);
    }

    public function add() {
        $data['brands'] = $this->Brand_model->get_all();
        $data['categories'] = $this->Product_category_model->get_all();

        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required|is_unique[products.code]');
        $this->form_validation->set_rules('brand_id','Brand','required');
        $this->form_validation->set_rules('product_category_id','Category','required');
        $this->form_validation->set_rules('date','Date','required');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            $this->layout('products/add', $data);
        } else {
            $insertData = [
                'name' => $this->input->post('name'),
                'code' => $this->input->post('code'),
                'brand_id' => $this->input->post('brand_id'),
                'product_category_id' => $this->input->post('product_category_id'),
                'date' => $this->input->post('date'),
                'description' => $this->input->post('description'),
                'status' => $this->input->post('status')
            ];
            $this->Product_model->insert($insertData);
            $this->session->set_flashdata('success','Product added successfully!');
            redirect('products');
        }
    }

    public function edit($id) {
        $product = $this->Product_model->get($id);
        if(!$product) show_404();

        $data['product'] = $product;
        $data['brands'] = $this->Brand_model->get_all();
        $data['categories'] = $this->Product_category_model->get_all();

        $this->form_validation->set_rules('name','Name','required');
        $this->form_validation->set_rules('code','Code','required');
        $this->form_validation->set_rules('brand_id','Brand','required');
        $this->form_validation->set_rules('product_category_id','Category','required');
        $this->form_validation->set_rules('date','Date','required');
        $this->form_validation->set_rules('status','Status','required');

        if($this->form_validation->run()===FALSE){
            
            $this->layout('products/edit', $data);
        } else {
            $code = $this->input->post('code');
            if($this->Product_model->code_exists_other($code,$id)){
                $this->session->set_flashdata('error','Code already exists!');
                redirect('products/edit/'.$id);
            }
            $updateData = [
                'name' => $this->input->post('name'),
                'code' => $code,
                'brand_id' => $this->input->post('brand_id'),
                'product_category_id' => $this->input->post('product_category_id'),
                'date' => $this->input->post('date'),
                'description' => $this->input->post('description'),
                'status' => $this->input->post('status')
            ];
            $this->Product_model->update($id,$updateData);
            $this->session->set_flashdata('success','Product updated successfully!');
            redirect('products');
        }
    }

    public function delete($id) {
        $this->Product_model->delete($id);
        $this->session->set_flashdata('successs','Product deleted successfully!');
        redirect('products');
    }

    public function view($id) {
        $data['product'] = $this->Product_model->get($id);
        if(!$data['product']) show_404();
        
        $this->layout('products/view', $data);
       
    }

}


    
    

