<?php
class Forms extends MY_Controller {
    
     public function __construct() {
        parent::__construct();
         $this->load->library('session');
         $this->load->model('User_model');
         $this->load->library('form_validation');
    }
//for login form
    public function general()
    {
        $data= [] ;
        $this->layout('general_form', $data);
    }


// for information form
    public function information()
    {
        $data= [] ;
        $this->layout('information_form', $data);
    }


//for registration form
    public function registration()
    {
        $data = []; 
        $this->layout('registration_form', $data);
    }





    //insert registration record into database
    public function register()
   {
            $this->load->model('User_model');
            $this->load->library('form_validation');

            $this->form_validation->set_rules('name', 'Name', 'required');

            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_gmail_check|is_unique[users.email]',
                array(
                     'required'    => 'Email is mandatory.',
                     'valid_email' => 'Please enter a valid email address.',
                     
                     ));

            $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]',
                   array(
                          'required'   => 'Password cannot be empty.',
                          'min_length' => 'Password must be at least 6 characters long.'
                        ));
              

                    
                   if ($this->form_validation->run() == FALSE) {
                        
                        $this->layout('registration_form.php'); 
                       } else {
                        
                           $name     = $this->input->post('name');
                           $email    = $this->input->post('email');
                           $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);

                          // Save to database 
                               $data = [
                                  'name'     => $name,
                                  'email'    => $email,
                                  'password' => $password
                                    ];

                                  $this->db->insert('users', $data); 
                                  redirect('Forms/general');
        
                              }
  }  



  // email pattern check function
                      public function gmail_check($email) {
                          if (preg_match('/^[a-z0-9._%+-]+@gmail\.com$/', $email))
                             {
                                  return TRUE;
                             } 
                        else {
                                $this->form_validation->set_message('gmail_check', 'The {field} must be a valid Gmail address (example@gmail.com).');
                                 return FALSE;
                             }
                            }
                            
         // inser data into user_info table                   
     public function information_form() {
         $this->load->model('User_model');
        if ($this->input->post()) {
            // Collect form data
            $data = array(
                'phone'       => $this->input->post('phone'),
                'dob'         => $this->input->post('dob'),
                'nid'         => $this->input->post('nid'),
                'address'     => $this->input->post('address'),
                'nationality' => $this->input->post('nationality')
            );

            // Insert into database
            $this->db->insert('user_info', $data);

            // Show success message
            $data['success'] = "Your information has been submitted successfully!";
            $this->layout('information_form', $data);
        } else {
    // Store error in flashdata for next request
    $this->session->set_flashdata('error', 'Email or password do not match!');
    redirect('Forms/general'); // Just redirect, no $data here
}

    }

//CRUD operation here

    public function information_list()
{
    $data['informations'] = $this->db->get('user_info')->result();
    $this->layout('information_list', $data);
}

public function edit($id)
{
    $data['info'] = $this->db->get_where('user_info', ['id' => $id])->row();
    $this->layout('update', $data);
}

public function delete($id)
{
    $this->db->where('id', $id)->delete('user_info');
    $this->session->set_flashdata('success', 'Information deleted successfully.');
    redirect('Forms/information_list');
}

public function update($id)
{
    $data = [
        'phone'       => $this->input->post('phone'),
        'dob'         => $this->input->post('dob'),
        'nid'         => $this->input->post('nid'),
        'address'     => $this->input->post('address'),
        'nationality' => $this->input->post('nationality'),
    ];

    $this->db->where('id', $id)->update('user_info', $data);
    $this->session->set_flashdata('success', 'Information updated successfully.');
    redirect('Forms/information_list');


}
}






