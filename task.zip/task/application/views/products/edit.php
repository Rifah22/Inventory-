<div class="card">
  <div class="card-header"><h3>Edit Product</h3></div>
  <div class="card-body">
    <?= form_open('products/edit/'.$product->id) ?>

    <?php if($this->session->flashdata('error')): ?>
    <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
    <?php endif; ?>
    
      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?= set_value('name',$product->name) ?>">
        <?= form_error('name','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Code</label>
        <input type="text" name="code" class="form-control" value="<?= set_value('code',$product->code) ?>">
        <?= form_error('code','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Brand</label>
        <select name="brand_id" class="form-control">
          <option value="">Select Brand</option>
          <?php foreach($brands as $b): ?>
            <option value="<?= $b->id ?>" <?= ($product->brand_id==$b->id)?'selected':'' ?>><?= $b->name ?></option>
          <?php endforeach; ?>
        </select>
        <?= form_error('brand_id','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Category</label>
        <select name="product_category_id" class="form-control">
          <option value="">Select Category</option>
          <?php foreach($categories as $c): ?>
            <option value="<?= $c->id ?>" <?= ($product->product_category_id==$c->id)?'selected':'' ?>><?= $c->name ?></option>
          <?php endforeach; ?>
        </select>
        <?= form_error('product_category_id','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Date</label>
        <input type="date" name="date" class="form-control" value="<?= set_value('date',$product->date) ?>">
        <?= form_error('date','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Description</label>
        <textarea name="description" class="form-control"><?= set_value('description',$product->description) ?></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="active" <?= ($product->status=='active')?'selected':'' ?>>Active</option>
          <option value="inactive" <?= ($product->status=='inactive')?'selected':'' ?>>Inactive</option>
        </select>
        <?= form_error('status','<small class="text-danger">','</small>') ?>
      </div>
      <button type="submit" class="btn btn-success">Update</button>
      <a href="<?= site_url('products') ?>" class="btn btn-secondary">Cancel</a>
    <?= form_close() ?>
  </div>
</div>
