<a href="<?= site_url('Dashboards/index') ?>" title="Back">
    <i class="fa fa-arrow-circle-left" style="font-size:40px;color:blue"></i>
</a>

<div class="card">
  <div class="card-header bg-indigo text-white">
    <h3 class="card-title">Products</h3>
    <a href="<?= site_url('products/add') ?>" class="btn btn-primary float-right">Add Product</a>
  </div>

  <div class="card-body">
    <form method="get" class="row g-2 mb-3">
      <div class="col-md-3">
        <input type="text" name="name" class="form-control" placeholder="Search by Name" value="<?= $name ?>">
      </div>
      <div class="col-md-3">
        <input type="text" name="code" class="form-control" placeholder="Search by Code" value="<?= $code ?>">
      </div>
      <div class="col-md-3">
        <select name="brand_id" class="form-control">
          <option value="">Select Brand</option>
          <?php foreach ($brands as $brand): ?>
            <option value="<?= $brand->id ?>" <?= $brand_id == $brand->id ? 'selected' : '' ?>>
                <?= $brand->name ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select name="category_id" class="form-control">
          <option value="">Select Category</option>
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat->id ?>" <?= $category_id == $cat->id ? 'selected' : '' ?>>
                <?= $cat->name ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-12 d-flex mt-2">
        <button type="submit" class="btn btn-primary btn-sm me-2"><i class="fas fa-search"></i> Search</button>
        <a href="<?= site_url('products') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-sync-alt"></i> Reset</a>
      </div>
    </form>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Code</th>
          <th>Brand</th>
          <th>Category</th>
          <th>Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($products)): ?>
          <?php foreach($products as $p): ?>
            <tr>
              <td><?= $p->id ?></td>
              <td><?= $p->name ?></td>
              <td><?= $p->code ?></td>
              <td><?= $p->brand_name ?></td>
              <td><?= $p->category_name ?></td>
              <td><?= $p->date ?></td>
              <td><span class="badge badge-success"><?= $p->status ?></span></td>
              <td>
                <a href="<?= site_url('products/view/'.$p->id) ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a>
                <a href="<?= site_url('products/edit/'.$p->id) ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                <a href="<?= site_url('products/delete/'.$p->id) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="8" class="text-center">No products found</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center mt-3">
      <?= $pagination ?>
    </div>
  </div>
</div>
