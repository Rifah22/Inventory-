<div class="card">
  <div class="card-header"><h3>Product Details</h3></div>
  <div class="card-body">
    <table class="table table-bordered">
      <tr><th>ID</th><td><?= $product->id ?></td></tr>
      <tr><th>Name</th><td><?= $product->name ?></td></tr>
      <tr><th>Code</th><td><?= $product->code ?></td></tr>
      <tr><th>Brand</th><td><?= $product->brand_id ?></td></tr>
      <tr><th>Category</th><td><?= $product->product_category_id ?></td></tr>
      <tr><th>Date</th><td><?= $product->date ?></td></tr>
      <tr><th>Description</th><td><?= $product->description ?></td></tr>
      <tr><th>Status</th><td><?= ucfirst($product->status) ?></td></tr>
      <tr><th>Created At</th><td><?= $product->created_at ?></td></tr>
      <tr><th>Updated At</th><td><?= $product->updated_at ?></td></tr>
    </table>
    <a href="<?= site_url('products') ?>" class="btn btn-secondary mt-3">Back</a>
  </div>
</div>
