<div class="card">
  <div class="card-header"><h3>Add Product</h3></div>
  <div class="card-body">
    <?= form_open('products/add') ?>
      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?= set_value('name') ?>">
        <?= form_error('name','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Code</label>
        <input type="text" name="code" class="form-control" value="<?= set_value('code') ?>">
        <?= form_error('code','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Brand</label>
        <select name="brand_id" class="form-control">
          <option value="">Select Brand</option>
          <?php foreach($brands as $b): ?>
            <option value="<?= $b->id ?>" <?= set_select('brand_id',$b->id) ?>><?= $b->name ?></option>
          <?php endforeach; ?>
        </select>
        <?= form_error('brand_id','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Category</label>
        <select name="product_category_id" class="form-control">
          <option value="">Select Category</option>
          <?php foreach($categories as $c): ?>
            <option value="<?= $c->id ?>" <?= set_select('product_category_id',$c->id) ?>><?= $c->name ?></option>
          <?php endforeach; ?>
        </select>
        <?= form_error('product_category_id','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Date</label>
        <input type="date" name="date" class="form-control" value="<?= set_value('date') ?>">
        <?= form_error('date','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Description</label>
        <textarea name="description" class="form-control"><?= set_value('description') ?></textarea>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="">Select Status</option>
          <option value="active" <?= set_select('status','active') ?>>Active</option>
          <option value="inactive" <?= set_select('status','inactive') ?>>Inactive</option>
        </select>
        <?= form_error('status','<small class="text-danger">','</small>') ?>
      </div>
      <button type="submit" class="btn btn-success">Save</button>
      <a href="<?= site_url('Dashboards/index') ?>" class="btn btn-secondary">Cancel</a>
    <?= form_close() ?>
  </div>
</div>
