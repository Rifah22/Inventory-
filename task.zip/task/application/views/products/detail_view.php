<!DOCTYPE html>
<html>
<head>
    <title>Product Detail</title>
</head>
<body>
    <h2>Product Detail</h2>

    <p><strong>Brand Name:</strong> <?php echo $product->brand_id; ?></p>
    <p><strong>Product Name:</strong> <?php echo $product->name; ?></p>
    <p><strong>Category Name:</strong> <?php echo $product->product_category_id; ?></p>

    <a href="<?php echo site_url('products'); ?>">Back to List</a>
</body>
</html>
