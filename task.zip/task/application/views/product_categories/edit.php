<div class="card">
  <div class="card-header"><h3>Edit Product Category</h3></div>
  <div class="card-body">
    <?= form_open('product_categories/edit/'.$category->id) ?>

    <?php if($this->session->flashdata('error')): ?>
    <div class="alert alert-danger"><?= $this->session->flashdata('error') ?></div>
    <?php endif; ?>

      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?= set_value('name',$category->name) ?>">
        <?= form_error('name','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Code</label>
        <input type="text" name="code" class="form-control" value="<?= set_value('code',$category->code) ?>">
        <?= form_error('code','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="active" <?= ($category->status=='active')?'selected':'' ?>>Active</option>
          <option value="inactive" <?= ($category->status=='inactive')?'selected':'' ?>>Inactive</option>
        </select>
        <?= form_error('status','<small class="text-danger">','</small>') ?>
      </div>
      <button type="submit" class="btn btn-success">Update</button>
      <a href="<?= site_url('product_categories') ?>" class="btn btn-secondary">Cancel</a>
    <?= form_close() ?>
  </div>
</div>
