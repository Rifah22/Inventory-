<div class="card">
  <div class="card-header"><h3>Add Product Category</h3></div>
  <div class="card-body">
    <?= form_open('product_categories/add') ?>
      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control" value="<?= set_value('name') ?>">
        <?= form_error('name','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Code</label>
        <input type="text" name="code" class="form-control" value="<?= set_value('code') ?>">
        <?= form_error('code','<small class="text-danger">','</small>') ?>
      </div>
      <div class="form-group">
        <label>Status</label>
        <select name="status" class="form-control">
          <option value="">Select Status</option>
          <option value="active" <?= set_select('status','active') ?>>Active</option>
          <option value="inactive" <?= set_select('status','inactive') ?>>Inactive</option>
        </select>
        <?= form_error('status','<small class="text-danger">','</small>') ?>
      </div>
      <button type="submit" class="btn btn-success">Save</button>
      <a href="<?= site_url('Dashboards/index') ?>" class="btn btn-secondary">Cancel</a>
    <?= form_close() ?>
  </div>
</div>
