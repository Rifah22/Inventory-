<a href="<?= site_url('Dashboards/index') ?>" title="Back"><i class="fa fa-arrow-circle-left" style="font-size:40px;color:blue"></i></a>

<div class="card">
  <div class="card-header bg-indigo text-white">
    <h3 class="card-title">Product Categories</h3>
    <a href="<?= site_url('product_categories/add') ?>" class="btn btn-primary float-right">Add Category</a>
  </div>
            
  <div class="card-body">
    <form method="get" class="mb-3 row">
      <div class="col-md-3">
        <input type="text" name="name" class="form-control" placeholder="Search by Name" value="<?= $this->input->get('name') ?>">
      </div>
      <div class="col-md-3">
        <input type="text" name="code" class="form-control" placeholder="Search by Code" value="<?= $this->input->get('code') ?>">
      </div>
      <div class="col-md-3">
        <select name="status" class="form-control">
          <option value="">Select Status</option>
          <option value="active" <?= ($this->input->get('status')=='active')?'selected':'' ?>>Active</option>
          <option value="inactive" <?= ($this->input->get('status')=='inactive')?'selected':'' ?>>Inactive</option>
        </select>
      </div>
      <div class="col-md-3">
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
        <a href="<?= site_url('product_categories') ?>" class="btn btn-secondary"><i class="fas fa-sync-alt"></i> Reset</a>
      </div>
    </form>

  <?php if($this->session->flashdata('success')): ?>
    <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
  <?php endif; ?>

  <?php if($this->session->flashdata('successs')): ?>
    <div class="alert alert-danger"><?= $this->session->flashdata('successs') ?></div>
  <?php endif; ?>
         
    <table class="table table-bordered table-striped">
      <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Code</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Actions</th>
            </tr>
      </thead>
          <tbody>
            <?php foreach($categories as $cat): ?>
              <tr>
                <td><?= $cat->id ?></td>
                <td><?= $cat->name ?></td>
                <td><?= $cat->code ?></td>
                <td class="status">
                  <span class="badge badge-success"><?= $cat->status; ?></span>
                </td>
                <td><?= $cat->created_at ?></td>
                <td>
                  <a href="<?= site_url('product_categories/view/'.$cat->id) ?>" class="btn btn-info btn-sm" title="View"><i class="fas fa-eye"></i></a>
                  <a href="<?= site_url('product_categories/edit/'.$cat->id) ?>" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                  <a href="<?= site_url('product_categories/delete/'.$cat->id) ?>" class="btn btn-danger btn-sm" title="Delete" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt"></i></a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
    </table>
    <div class="d-flex justify-content-center mt-3">
      <?= $pagination ?>
    </div>
  </div>
</div>

