<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | General Form Elements</title>

  <?php $this->load->view('styles'); ?>
</head>
<body class="hold-transition sidebar-mini">
<!-- Main content -->
    <!-- Horizontal Form -->
            <div class="card card-info">
              <div class="card-header">
                <h3 class="card-title">Admin Form</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form class="form-horizontal" action="<?php echo base_url('Logins/login'); ?>" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                      <input type="email"  name="email" class="form-control" id="inputEmail3" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10">
                      <input type="password"  name="password" class="form-control" id="inputPassword3" placeholder="Password">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="offset-sm-2 col-sm-10">
                      <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck2">
                        <label class="form-check-label" for="exampleCheck2">Remember me</label>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-info">Sign in</button>
                      <span class="text-center flex-grow-1">
                         Don't have an account? 
                         <a href="<?php echo site_url('Forms/registration'); ?>">Sign Up</a>
                      </span>
                  <button type="submit" class="btn btn-default float-right"><a href="<?php echo base_url(); ?>Dashboards/index" class="btn btn-default float-right">Cancel</a>
                </button>
                </div>
                <!-- /.card-footer -->
              </form>
            </div>
            <!-- /.card -->

          </div>
          <?php if ($this->session->flashdata('error')): ?>
    <div style="color: red;">
        <?= $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>


<?php $this->load->view('scripts'); ?>
</body>
</html>
