<!DOCTYPE html>
<html>
<head>
    <title>User Information List</title>
    <?php $this->load->view('styles'); ?>
</head>
<body>
<div class="container mt-5">
    <h2>User Information List</h2>

    

    <!-- Back to Add Form -->
    <a href="<?php echo base_url('Forms/information'); ?>" class="btn btn-primary mb-3">Add New</a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Phone</th>
                <th>Date of Birth</th>
                <th>NID</th>
                <th>Address</th>
                <th>Nationality</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(!empty($informations)): ?>
            <?php $i = 1; foreach($informations as $info): ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><?= $info->phone; ?></td>
                    <td><?= $info->dob; ?></td>
                    <td><?= $info->nid; ?></td>
                    <td><?= $info->address; ?></td>
                    <td><?= $info->nationality; ?></td>
                    <td>
                        <a href="<?= base_url('Forms/edit/'.$info->id); ?>" class="btn btn-warning btn-sm">Edit</a>
                        
                        <a href="<?= base_url('Forms/delete/'.$info->id); ?>" 
                           class="btn btn-danger btn-sm" 
                           onclick="return confirm('Are you sure you want to delete this record?');">
                           Delete
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">No information found.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $this->load->view('scripts'); ?>
</body>
</html>
