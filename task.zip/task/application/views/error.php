<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <div class="alert alert-danger text-center">
        <h4 class="alert-heading">Error!</h4>
        <p><?= isset($error_message) ? $error_message : 'Something went wrong.' ?></p>
    </div>
</div>
</body>
</html>
