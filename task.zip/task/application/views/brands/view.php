<div class="card">
  <div class="card-header"><h3>Brand Details</h3></div>
  <div class="card-body">
    <table class="table table-bordered">
      <tr><th>ID</th><td><?= $brand->id ?></td></tr>
      <tr><th>Name</th><td><?= $brand->name ?></td></tr>
      <tr><th>Code</th><td><?= $brand->code ?></td></tr>
      <tr><th>Status</th><td><?= ucfirst($brand->status) ?></td></tr>
      <tr><th>Created At</th><td><?= $brand->created_at ?></td></tr>
      <tr><th>Updated At</th><td><?= $brand->updated_at ?></td></tr>
    </table>
    <a href="<?= site_url('brands') ?>" class="btn btn-secondary mt-3">Back</a>
  </div>
</div>
