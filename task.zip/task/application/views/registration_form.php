<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | General Form Elements</title>

  <?php $this->load->view('styles'); ?>
</head>
<body class="hold-transition sidebar-mini">

<section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Registration Form</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="<?php echo base_url('Forms/register'); ?>" method="post" enctype="multipart/form-data">
    <div class="card-body">

        <div class="form-group">
            <label for="exampleInputName">Name</label>
            <input type="text" name="name" class="form-control" id="exampleInputName" 
                   placeholder="Enter Name" value="<?php echo set_value('name'); ?>">
            <small class="text-danger"><?php echo form_error('name'); ?></small>
        </div>

        <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" name="email" class="form-control" id="exampleInputEmail1" 
                   placeholder="Enter email" value="<?php echo set_value('email'); ?>">
            <small class="text-danger"><?php echo form_error('email'); ?></small>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1" 
                   placeholder="Password">
            <small class="text-danger"><?php echo form_error('password'); ?></small>
        </div>

    </div>

    <div class="card-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>


            <!-- /.card -->
             <?php $this->load->view('scripts'); ?>
</body>
</html>