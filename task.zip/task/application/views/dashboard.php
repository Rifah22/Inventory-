
<div class="row">
          <div class="col-lg-6 col-12">
            <!-- small box -->
            <div class="small-box bg-indigo">
              <div class="inner">
                <h3> </h3>
                <p>Add Brands</p>
              </div>
              <div class="icon">
                <i class="ion-social-bitcoin" style="font-size:40px;color:white;"></i>    
              </div>
              <a href="<?php echo base_url(); ?>Brands/add" class="small-box-footer">Cilck here<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-6 col-12">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3> </h3>
                <p>Add Product Categories </p>
              </div>
              <div class="icon">
                <i class="ion-briefcase" style="font-size:40px;color:white;"></i>
              </div>
              <a href="<?php echo base_url(); ?>product_categories/add" class="small-box-footer">Cilck here<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-6 col-12">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3> </h3>
                <p>Add Products</p>
              </div>
              <div class="icon">
                <i class="ion-ios-cart" style="font-size:40px;color:black;"></i>
              </div>
              <a href="<?php echo base_url(); ?>products/add" class="small-box-footer">Cilck here<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-6 col-12">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3> </h3>
                <p>All Detail</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph" style="font-size:40px;color:black;"></i>
              </div>
              <a href="#" class="small-box-footer">Cilck here<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        
            <!-- /.card -->

            <!-- DIRECT CHAT -->
            
              <!-- /.card-header -->
              
                  <!-- /.direct-chat-msg -->

                  <!-- Message to the right -->
                  
                  <!-- /.direct-chat-msg -->

                  <!-- Message. Default to the left -->
                  
                  
                <!--/.direct-chat-messages-->

                <!-- Contacts are loaded here -->
                
            
            <!-- /.card -->
            
            <!-- right col -->
            </div>
