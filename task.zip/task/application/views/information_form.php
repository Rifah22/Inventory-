<!DOCTYPE html>
<html>
<head>
    <title>User Information Form</title>
    
    <?php $this->load->view('styles'); ?>
</head>
<body>
<div class="container mt-5">
    <h2>User Information Form</h2>

    <?php if(isset($success)): ?>
        <div class="alert alert-success"><?= $success; ?></div>
    <?php endif; ?>
    <form action="<?php echo base_url('Forms/information_list'); ?>" method="post">
        <button type="submit" class="btn btn-primary">See All</button>
    </form>

    <form action="<?php echo base_url('Forms/information_form'); ?>" method="post">
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control">
        </div>

        <div class="form-group">
            <label>Date of Birth</label>
            <input type="date" name="dob" class="form-control">
        </div>

        <div class="form-group">
            <label>NID</label>
            <input type="text" name="nid" class="form-control">
        </div>

        <div class="form-group">
            <label>Address</label>
            <textarea name="address" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label>Nationality</label>
            <input type="text" name="nationality" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $this->load->view('scripts'); ?>
</body>
</html>
