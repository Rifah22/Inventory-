<!DOCTYPE html>
<html>
<head>
    <title>Edit User Information</title>
    <?php $this->load->view('styles'); ?>
</head>
<body>
<div class="container mt-5">
    <h2>Edit Information</h2>

    <form action="<?= base_url('Forms/update/'.$info->id); ?>" method="post">
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= $info->phone; ?>">
        </div>

        <div class="form-group">
            <label>Date of Birth</label>
            <input type="date" name="dob" class="form-control" value="<?= $info->dob; ?>">
        </div>

        <div class="form-group">
            <label>NID</label>
            <input type="text" name="nid" class="form-control" value="<?= $info->nid; ?>">
        </div>

        <div class="form-group">
            <label>Address</label>
            <textarea name="address" class="form-control"><?= $info->address; ?></textarea>
        </div>

        <div class="form-group">
            <label>Nationality</label>
            <input type="text" name="nationality" class="form-control" value="<?= $info->nationality; ?>">
        </div>

        <button type="submit" class="btn btn-success">Update</button>
        <a href="<?= base_url('Forms/information_list'); ?>" class="btn btn-secondary">Back</a>
    </form>
</div>
<?php $this->load->view('scripts'); ?>
</body>
</html>
