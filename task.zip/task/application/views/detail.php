<!DOCTYPE html>
<html>
<head>
    <title>Product Detail</title>
</head>
<body>
    <h2>Product Detail</h2>

    <p><strong>Brand Name:</strong> <?php echo $product->brand_name; ?></p>
    <p><strong>Product Name:</strong> <?php echo $product->product_name; ?></p>
    <p><strong>Category Name:</strong> <?php echo $product->category_name; ?></p>

    <a href="<?php echo site_url('Dsahbards/index'); ?>">Back to List</a>
</body>
</html>
