
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function count_filtered_products($name = null, $code = null, $brand_id = null, $category_id = null) {
        $this->db->from('products p')
                 ->join('brands b', 'b.id=p.brand_id', 'left')
                 ->join('product_categories c', 'c.id=p.product_category_id', 'left');

        if ($name) $this->db->like('p.name', $name);
        if ($code) $this->db->like('p.code', $code);
        if ($brand_id) $this->db->where('p.brand_id', $brand_id);
        if ($category_id) $this->db->where('p.product_category_id', $category_id);

        return $this->db->count_all_results();
    }

    public function get_filtered_products($limit, $offset, $name = null, $code = null, $brand_id = null, $category_id = null) {
        $this->db->select('p.*, b.name AS brand_name, c.name AS category_name')
                 ->from('products p')
                 ->join('brands b', 'b.id=p.brand_id', 'left')
                 ->join('product_categories c', 'c.id=p.product_category_id', 'left');

        if ($name) $this->db->like('p.name', $name);
        if ($code) $this->db->like('p.code', $code);
        if ($brand_id) $this->db->where('p.brand_id', $brand_id);
        if ($category_id) $this->db->where('p.product_category_id', $category_id);

        $this->db->limit($limit, $offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function get_all() {
        return $this->db->get('products')->result();
    }

    public function get($id) {
        return $this->db->get_where('products',['id'=>$id])->row();
    }

    public function insert($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        $this->db->insert('products',$data);
    }

    public function update($id,$data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id',$id)->update('products',$data);
    }

    public function delete($id) {
        $this->db->where('id',$id)->delete('products');
    }

    public function code_exists_other($code,$id) {
        return $this->db->where('code',$code)->where('id !=',$id)->get('products')->num_rows()>0;
    }

}





