
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brand_model extends CI_Model {


    public function count_filtered_brands($name = null, $code = null,$status=null) {
        
        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);
        
        return $this->db->count_all_results('brands');
    }

    public function get_filtered_brands($limit, $offset,$name = null, $code = null,$status=null) {
        
        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);
        
        $this->db->limit($limit, $offset);
        return $this->db->get('brands')->result();
    }

    public function get_all() {
        return $this->db->get('brands')->result();
    }

    public function get($id) {
        return $this->db->get_where('brands',['id'=>$id])->row();
    }

    public function insert($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        $this->db->insert('brands',$data);
    }

    public function update($id,$data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id',$id)->update('brands',$data);
    }

    public function delete($id) {
        $this->db->where('id',$id)->delete('brands');
    }

    public function code_exists_other($code,$id) {
        return $this->db->where('code',$code)->where('id !=',$id)->get('brands')->num_rows()>0;
    }
}




