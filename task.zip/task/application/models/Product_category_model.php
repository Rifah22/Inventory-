<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_category_model extends CI_Model {

    public function count_filtered_categories($name = null, $code = null,$status=null) {
        
        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);
        
        return $this->db->count_all_results('product_categories');
    }

    public function get_filtered_categories($limit, $offset,$name = null, $code = null,$status=null) {
        
        if($name) $this->db->like('name', $name);
        if($code) $this->db->like('code', $code);
        if($status) $this->db->where('status', $status);
        
        $this->db->limit($limit, $offset);
       return $this->db->get('product_categories')->result();
       
    }



    public function get_all() {
        return $this->db->get('product_categories')->result();
    }

    public function get($id) {
        return $this->db->get_where('product_categories',['id'=>$id])->row();
    }

    public function insert($data) {
        $data['created_at'] = date('Y-m-d H:i:s');
        $this->db->insert('product_categories',$data);
    }

    public function update($id,$data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where('id',$id)->update('product_categories',$data);
    }

    public function delete($id) {
        $this->db->where('id',$id)->delete('product_categories');
    }

    public function code_exists_other($code,$id) {
        return $this->db->where('code',$code)->where('id !=',$id)->get('product_categories')->num_rows()>0;
    }
}



/*<?php
class Product_category_model extends CI_Model {
    protected $table = 'product_categories';
    public function get_all() { return $this->db->order_by('id','DESC')->get($this->table)->result(); }
    public function get($id) { return $this->db->where('id',$id)->get($this->table)->row(); }
    public function insert($data) { return $this->db->insert($this->table,$data); }
    public function update($id,$data) { return $this->db->where('id',$id)->update($this->table,$data); }
    public function delete($id) { return $this->db->delete($this->table,['id'=>$id]); }
    public function code_exists_other($code,$id){ return $this->db->where('code',$code)->where('id !=',$id)->get($this->table)->num_rows()>0; }
}*/
