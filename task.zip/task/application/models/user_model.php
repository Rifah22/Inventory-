<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

  public function insert_user($data)
{
  
    return $this->db->insert('users', $data);
}
  //      public function email_exists($email)
  //  {
  //   $this->db->where('email', $email);
  //   $query = $this->db->get('users');
  //   return $query->num_rows() > 0;
  // }

  

}
