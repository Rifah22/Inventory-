<?php
class Detail_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_product_detail($id) {
        $this->db->select('products.product_name, brands.brand_name, categories.category_name');
        $this->db->from('products');
        $this->db->join('brands', 'brands.id = products.brand_id');
        $this->db->join('categories', 'categories.id = products.category_id');
        $this->db->where('products.id', $id);
        $query = $this->db->get();
        return $query->row(); 
    }
}
