<?php


class MY_Loader extends CI_Loader 
{
    // public function view($view, $vars = Array(), $return = false) {
    //     exit("lksdjfksf");
    // }
}