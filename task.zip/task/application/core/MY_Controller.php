<?php

class MY_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
         $this->load->library('form_validation');
         $this->load->library('session');
    }

    public function layout($view, $data = array(), $return_type = false) {

         return $this->load->view('app', ['content' => $this->load->view($view, $data, true)], $return_type);

    }

}